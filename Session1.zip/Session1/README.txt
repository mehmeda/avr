---Session 1---


Task 1:

Learn how to open Atmel Studio.
Read the code, what do you think it does?
Learn how to upload code.


Task 2:

Set up a button with pullup. Use this to control the led.


Task 3:

Add aditional logic so that the button toggles the led.


Task 4: (OPTIONAL)

Add the OLED board.
Find out where the buttons and LEDs connect.
Do something fun with the additional leds and buttons.
